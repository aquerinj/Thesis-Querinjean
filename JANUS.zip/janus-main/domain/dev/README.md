# Dev domain

You will find here the jumpbox and the tools that will be used for janus project development. These tools are still being defined and implemented, as are the future services to be used.

## List of services :
- Mattermost
- Jitsi

## List of tools : 
- Github
- VSCode
- Bootstrap
- IntelliJIdea


