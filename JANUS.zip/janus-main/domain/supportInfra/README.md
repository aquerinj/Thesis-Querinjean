# supportInfra domain

This domain includes the firewall, a Web Application Firewall (WAF), a reverse proxy, and a DNS server. 
