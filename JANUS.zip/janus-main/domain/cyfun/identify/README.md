# CyFun ID.AM-1 – Infrastructure and Asset Inventory

This module ensures compliance with CyFun ID.AM-1 by:

- Automatically generating an infrastructure inventory (`assets.yml`)
- Providing a template to manually complete human-visible assets (`manual-assets.yml`)
- Including a policy for review/update
- Ensuring everything is versioned, reviewable, and reproducible

## Usage

The infrastructure is automatically inventoried each time `vagrant up` is performed.

This will generate the file:

`/domain/cyfun/identify/inventory/assets.yml`

Then complete the file:

`/domain/cyfun/identify/inventory/manual-assets.yml`

You must include:

- All laptops, desktops, mobile phones, tablets
- Printers, routers, switches, and other unmanaged devices

to check that you have respected everything use the checklist :
`checklist-ID.AM-1.md`