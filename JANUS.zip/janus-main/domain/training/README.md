# Training domain

Contains CTFd (Capture The Flag platform)

