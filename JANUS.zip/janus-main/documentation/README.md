# Documentation 

Here you will find folders such as:
- Images
- Rules
- SolutionToSomeIssue
- Tools

## Images
Contains all images necessary for explanations regarding the Janus project.

## Rules
Rules to follow when working on the Janus project.

## Solution to some issue 
A list of solutions to address future problems.

## Tools
A list of tools and keywords.
