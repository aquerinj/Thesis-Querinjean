## 1 Week 02-08 - 02-09

- **Tasks** :
  - Task 1: appropriation et lancement du projet

## 2 Week 02-12 02-16

- **Tasks** :
  - Task 1: appropriation et lancement du projet
  - Task 2: work on yourls service

## 3 Week 02-19 02-23

- **Tasks** :
  - Task 1: day2day
  - Task 2: work on yourls service
  - Task 3: work on mattermost issue https://gitlab.com/jdosec/redteamtdi/-/issues/2

## 4 Week 7 02-26 03-01

- **Tasks** :
  - Task 1: day2day monarc
  - Task 2: work on mattermost issue https://gitlab.com/jdosec/redteamtdi/-/issues/2

## 5 Week 03-04 03-08

- **Tasks** :
  - Task 1: day2day ISO 27002

## 6 Week 03-11 03-14

- **Tasks** :
  - Task 1: Refactoring README.md + Template
  - Task 2: Mooving all meeting => Wiki + Template
  - Task 3: Changing ip + port for all services

## 7 Week 03-18 03-22

- **Tasks** :
  - Task 1: day2day Iso Mapping
  - Task 2: Changing ip + port for all services
  - Task 3: Refactoring of the structure

## 8 Week 03-25 03-29

- **Tasks** :
  - Task 1: Refactoring Step 2 https://gitlab.com/jdosec/janus/-/issues/3
  - Task 2: Refactoring 

## 9 Week 04-02 04-05

- **Tasks** :
  - Task 1: Logical diagram & structure
  - Task 2: Refactoring Step 2 https://gitlab.com/jdosec/janus/-/issues/3
  - Task 3: Refactoring Step 3 https://gitlab.com/jdosec/janus/-/issues/4
  - Task 4: Add syncthing - logseq - incoiceninja
  - Task 5: Refactoring janus

## 10 Week 04-08 04-12

- **Tasks** :
  - Task 1: Refactoring janus
  - Task 2: Implement Codimd and bitwarden
  - Task 3: Add mattermost backup
  - Task 4: Add rules and logical diagram and structure

## 11 Week 04-15 04-19

- **Tasks** :
  - Task 1: Refactoring, Issues, Readme, Backup
  - Task 2: terraform

## 12 Week 04-22 04-26

- **Tasks** :
  - Task 1: terraform
  - Task 2: Reverse Proxy

## 12 Week 04-29 05-03

- **Tasks** :
  - Task 1: Reverse Proxy : Nextcloud
  - Task 2: Terraform
  - Task 3: Fill Readme

## 13 Week 05-06 05-10

- **Tasks** :
  - Task 1: Add sonarqube in old janus-2023 project
  - Task 2: Pipeline

## 14 Week 05-13 05-15

- **Tasks** :
  - Task 1: Sonarqube
  - Task 2: Pipeline
