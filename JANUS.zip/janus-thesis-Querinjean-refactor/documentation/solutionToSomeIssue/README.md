# Solutions to some issue

During the execution of playbooks, if you have issue with docker-compose, install this

``ansible-galaxy collection install community.docker``

