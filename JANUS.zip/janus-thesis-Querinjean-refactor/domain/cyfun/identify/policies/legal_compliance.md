
# Legal and Regulatory Compliance

This document explains the main legal and cybersecurity rules for our accounting firm in Belgium. It helps meet **CyFun ID.GV-3** (governance) and follows **NIS2** rules, active since October 2024.

All team members (managers, accountants, secretary) must know these rules. The **Directive Manager** ensures they are followed.

---

## 1. Main Legal Rules

### 1.1 General Data Protection Regulation (GDPR)
- We handle clients personal and financial data.
- Data must be safe (strong passwords, encryption, secure backups).
- Clients can ask to see, change, or delete their data.
- If there’s a data breach, we must tell the Belgian Data Protection Authority (APD) within **72 hours**.

### 1.2 Belgian Accounting Law
- Accounting documents must be kept for **at least 7 years**.
- Documents must be ready for tax authorities if requested.
- Digital storage is allowed but must be secure and organized.

### 1.3 Confidentiality Rules
- As accountants, we must keep client data private.
- Only authorized staff can access sensitive files.
- Personal USB drives or private email accounts are not allowed.

### 1.4 NIS2 Directive

- **Our firm may be an “important entity” or a supplier to critical sectors (e.g., healthcare, finance).**
- **CyFun level 1 meets basic NIS2 needs, but extra steps (e.g., audits, documentation) may be needed for full compliance.**

---

## 2. Our Actions

| Rule                            | How We Follow It                                                               | Who’s Responsible | SMART Goal                                                             |
|--------------------------------|--------------------------------------------------------------------------------|-------------------|------------------------------------------------------------------------|
| GDPR – Protect Client Data     | Strong passwords, limited access, encrypted backups via **JANUS**              | Directive Manager | **Test 100% of backups monthly, checked with JANUS reports.**          |
| GDPR – Client Data Requests    | Clients can email to update or delete data                                     | Secretary         | **Handle 95% of requests in 5 working days, checked every 3 months.**  |
| GDPR – Report Data Breach      | Process in place, reviewed yearly,                                             | Directive Manager | **Report 100% of breaches to APD in 72 hours, checked yearly.**        |
| Accounting – 7-Year Storage    | Store documents on TO_BE_FILLED (Nextcloud) , **set up by JANUS**              | Accountant        | **Test 95% of documents for access every 6 months.**                   |
| Confidentiality                | Work accounts only, monitored via **JANUS SIEM**                               | All Employees     | **No cases of unauthorized devices, checked every 3 months.**          |
| **NIS2 – Supplier Security**   | **Check suppliers yearly (e.g., Nextcloud GDPR/NIS2 compliance)**              | Directive Manager | **Evaluate 100% of suppliers by December each year.**                  |
---

## 3. Review and Updates

This document must be checked every year or when new rules appear. The **Directive Manager** handles updates. Changes are recorded below.

---

## Review History

| Date            | Reviewed By       | Comment                        |
|-----------------|-------------------|--------------------------------|
| TO_BE_FILLED    | Directive Manager | Initial version for CyFun and NIS2 |

---

**Last Review**: TO_BE_FILLED