# Invoice ninja

## Installation

To install Invoice Ninja, I followed the instructions on the [official github](https://github.com/invoiceninja/dockerfiles) and [official docker hub](https://hub.docker.com/r/invoiceninja/invoiceninja/).




