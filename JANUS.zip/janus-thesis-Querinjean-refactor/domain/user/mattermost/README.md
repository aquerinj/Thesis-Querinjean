# Mattermost

## Getting started

I followed the [official documentation](https://docs.mattermost.com/install/install-docker.html#deploy-mattermost-on-docker-for-production-use) to install Mattermost on docker.

## Configuration Files

### Focalboard 

Focalboard is already integrated in Mattermost. This is now called "Boards" in the top-right menu, next to the 'Start call' button.
