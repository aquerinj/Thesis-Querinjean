# Specific password generation


CTFd, bitwarden and Syncthing have specific password generation requirements since we need to **hash** the password in order to use it.

The scripts provided in this directory are used to generate the passwords for these services.