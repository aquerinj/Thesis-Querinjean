# IT domain

Here you'll find the tools you need for IT . 
These tools are still to be defined and implemented, as are the future services to be used.

## List of services : 
(for example) 
- mattermost
- jitsi

## List of tools : 
- Cryptography tools
- Conversion tools
- Web development tools
- Networking tools
