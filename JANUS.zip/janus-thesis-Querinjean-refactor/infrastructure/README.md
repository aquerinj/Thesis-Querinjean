# Infrastructure Overview

You will find the proxmox configuration, hetzner, etc...

## Terraform

Terraform enabled us to deploy a virtual machine that will be hosted on a remote Hetzner server. Terraform is a crucial tool for automation and remote provisioning, which is why we use it


